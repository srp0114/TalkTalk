// 채팅방id와 user 정보가 담긴 클래스
public class Room {
	int roomId;
	String userlist;
	public Room(int roomId, String userlist) {
		this.roomId = roomId;
		this.userlist = userlist;
	}
	public void addUser(String username) {
		this.userlist += " " + username;
	}
}
