package util;

import java.awt.Color;

public class ColorDefinition {
	public static final Color kakaoWhite = new Color(255,255,255);
	public static final Color kakaoYello = new Color(254,229,0);
}
